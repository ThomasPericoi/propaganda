<!-- Intro -->
<div class="intro">
    <div class="container align-center">
        <h1><?php echo $args['title']; ?></h1>
        <p><?php echo $args['text']; ?></p>
    </div>
</div>