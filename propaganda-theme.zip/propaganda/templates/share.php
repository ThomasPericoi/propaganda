<!-- Share -->
<div class="socials share">
    <span>Share on:</span>
    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $args['url']; ?>" rel="external" target="_blank" class="btn-icon btn-3d-<?php echo $args['color']; ?> social">
        <i class="fab fa-facebook-f"></i></i>
    </a>
    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $args['url']; ?>" rel="external" target="_blank" class="btn-icon btn-3d-<?php echo $args['color']; ?> social">
        <i class="fab fa-linkedin-in"></i></i>
    </a>
    <a href="http://www.reddit.com/submit?url=<?php echo $args['url']; ?>" rel="external" target="_blank" class="btn-icon btn-3d-<?php echo $args['color']; ?> social">
        <i class="fab fa-reddit-alien"></i></i>
    </a>
    <a href="https://twitter.com/intent/tweet?url=<?php echo $args['url']; ?>" rel="external" target="_blank" class="btn-icon btn-3d-<?php echo $args['color']; ?> social">
        <i class="fab fa-twitter"></i></i>
    </a>
</div>