<div class="outro">
    <h3 class="align-center"><?php echo $args['title']; ?></h3>
    <div class="button-wrapper">
        <a href="<?php echo $args['btn_link']; ?>" class="btn btn-<?php echo $args['color']; ?>"><?php echo $args['btn_label']; ?></a>
    </div>
</div>