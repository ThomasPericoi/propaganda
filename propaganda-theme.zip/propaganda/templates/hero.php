<!-- Hero -->
<section class="hero hero-<?php echo $args['color']; ?>">
    <div class="container">
        <div class="align-center">
            <h1><span><?php echo $args['title']; ?></span></h1>
            <p class="h3-size"><?php echo $args['subtitle']; ?></p>
        </div>
    </div>
</section>